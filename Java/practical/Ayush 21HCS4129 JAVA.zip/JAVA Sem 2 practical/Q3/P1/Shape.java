package P1;
abstract public class Shape{
     abstract public float area();
     abstract public void getdata();
}