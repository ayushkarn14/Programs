public class OverFlow extends Exception {
    public String toString() {
        return ("Stack is full");
    }
}
