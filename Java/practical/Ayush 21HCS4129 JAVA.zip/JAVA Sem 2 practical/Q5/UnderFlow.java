public class UnderFlow extends Exception {
    public String toString() {
        return ("Stack is empty");
    }
}