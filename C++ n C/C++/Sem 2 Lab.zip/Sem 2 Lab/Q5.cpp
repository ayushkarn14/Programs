//not done
#include <iostream>
using namespace std;
class Q5{
    int a;
    Q5(int x){
        a=x;
    }
    public:
        int fib();
};
Q5::int fib(int i){
    if(i==0 && i==1)
        return i;
    else{
        return (fib(i-2)+fib(i-1));
    }
}
int main(){
    cout<<"Enter number of terms";
    int n,i;
    cin>>n;
    Q5 ob(n);
    while(i<n){

    }
}