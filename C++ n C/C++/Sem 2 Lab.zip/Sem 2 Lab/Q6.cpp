//tower of hanoi
#include <iostream>
using namespace std;
void M(int n, char f, char t, char v)
{
    if (n > 0)
    {
    }
}