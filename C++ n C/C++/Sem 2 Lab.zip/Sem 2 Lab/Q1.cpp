#include <iostream>
using namespace std;
class Q1
{
    int *arr;
    int l;
    int *un;
    int c;

public:
    void input();
    void build_set();
    void display();
    Q1(int size)
    {
        arr = new int[size];
        un = new int[size];
        l = size;
    }
};
void Q1::input()
{
    cout << "Enter the elements in array" << endl;

    for (int i = 0; i < l; i++)
    {
        cin >> arr[i];
    }
}
void Q1::build_set()
{
    int c = 0;
    for (int i = 0; i < l; i++)
    {
        int f = 0;
        for (int j = 0; j < c; j++)
        {
            if (arr[i] == un[j])
            {
                f = 1;
            }
        }
        if (f == 0)
        {
            un[c] = arr[i];
            c++;
        }
    }
    delete[] arr;
    arr = new int[c];
    for (int i = 0; i < c; i++)
        arr[i] = un[i];
    delete[] un;
    l = c;
}
void Q1::display()
{
    for (int i = 0; i < l; i++)
    {
        cout << arr[i] << " ";
    }
}
// int main()
// {
//     cout << "Enter size of array: ";
//     int len;
//     cin >> len;
//     Q1 ob(len);
//     ob.input();
//     ob.build_set();
//     ob.display();
// }