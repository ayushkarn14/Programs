//incomplete 
#include <iostream>
using namespace std;
class Q9{
    public:
        int *arr;
        int l,c,temp;
        void ins_sort();
        void set_values();
        Q9(int x){
            temp=0;
            c=0;
            l=x;
            arr=new int[l];
        }
        ~Q9(){
            delete[] arr;
        }

};

void Q9::set_values(){
        srand(time(0));
    for(int i=0;i<l;i++){
        arr[i]=rand()%100+1;
    }
}

void Q9::ins_sort(){
    for(int j=0;j<l;j++)
        cout<<arr[j]<<" ";
    cout<<endl;


    for(int i=1;i<l;i++){
    int cc=0;
        for(int j=i+1;arr[j]<arr[j-1];j--){
            if(j==l)
            break;
            temp=arr[j];
            arr[j]=arr[j-1];
            arr[j-1]=temp;
            cc++;c++;
        }
        for(int j=0;j<l;j++)
            cout<<arr[j]<<" ";
        cout<<"     No. of shifts = "<<cc;
        cout<<endl;
    }
    cout<<"Total number of shifts = "<<c<<endl;
}

int main(){
    cout<<"Enter number of values: ";
    int s;
    cin>>s;
    Q9 ob(s);
    ob.set_values();
    ob.ins_sort();
}